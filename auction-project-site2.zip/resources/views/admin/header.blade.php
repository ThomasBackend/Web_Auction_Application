<div class="container-fluid page-body-wrapper">
  <!-- partial:partials/_navbar.html -->
  <nav class="navbar p-0 fixed-top d-flex flex-row">
    <div class="navbar-brand-wrapper d-flex d-lg-none align-items-center justify-content-center">
      <a class="navbar-brand brand-logo-mini" href="{{ url('redirect') }}"><img src="assets/images/logo-mini.svg" alt="logo" /></a>
    </div>
    <div class="navbar-menu-wrapper flex-grow d-flex align-items-stretch">
      
      <ul class="navbar-nav w-100">
        <li class="nav-item w-100">
          
        </li>
      </ul>
      <ul class="navbar-nav navbar-nav-right">
        <li class="nav-item dropdown d-none d-lg-block">
         
        </li>
        <li class="nav-item nav-settings d-none d-lg-block">
          
        </li>
        <li class="nav-item dropdown border-left">
         
        </li>
        <li class="nav-item dropdown border-left">
         
        </li>
        <li>
          <x-app-layout>

          </x-app-layout>
        </li>
    </div>
  </nav>