<!DOCTYPE html>
<html lang="en">
  <head>
 <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

 <style type="text/css">

.center{
  margin:auto;
  width: 50%;
  border: 2px solid white;
  text-align: center;
  margin-top: 40px;
}
.font_size{
  text-align: center;
  font-size: 40px;
  padding-top: 20px;
}
.img_size{
  width: 250px;
  height: 150px;
}
.th_color{
  background: skyblue;
}
.th_deg{
  padding: 30px;
}
</style>
  </head>
  <body>
    <div class="container-scroller">
      <!-- partial:partials/_sidebar.html -->
    <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- partial -->
      <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">

            <?php if(session()->has('message')): ?>
    <div class="alert alert-success">
      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">X</button>

      <?php echo e(session()->get('message')); ?>


    </div>
      
    <?php endif; ?>

<h2 class="font_size">All Products</h2>

<table class="center">

<tr class="th_color">
<th class="th_deg">Product Title</th>
<th class="th_deg">Image</th>
<th class="th_deg">Description</th>
<th class="th_deg">Slug</th>
<th class="th_deg">Start Date</th>
<th class="th_deg">End Date</th>
<th class="th_deg">Starting Price</th>
<th class="th_deg">End Price</th>
<th class="th_deg">Winner</th>
<th class="th_deg">Delete</th>
<th class="th_deg">Edit</th>
</tr>

<?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  
<tr>
  <td><?php echo e($product->title); ?></td>
  <td>
    <img class="img_size" src="/product/<?php echo e($product->image); ?>">
  </td>
  <td><?php echo e($product->description); ?></td>
  <td><?php echo e($product->slug); ?></td>
  <td><?php echo e($product->start_date); ?></td>
  <td><?php echo e($product->end_date); ?></td>
  <td><?php echo e($product->starting_price); ?></td>
  <td><?php echo e($product->current_price); ?></td>
  <td><?php echo e($product->winner_id); ?></td>
  
  <td>
    <a class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this product?')" href="<?php echo e(url('delete_product',$product->id)); ?>">Delete</a>
  </td>

  <td>
    <a class="btn btn-success" href="<?php echo e(url('update_product',$product->id)); ?>">Edit</a>
  </td>

</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>



          </div>
        </div>        
    <!-- container-scroller -->
    <!-- plugins:js -->
   <?php echo $__env->make('admin.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </body>
</html><?php /**PATH C:\xampp\htdocs\auction-project-site\resources\views/admin/show_product.blade.php ENDPATH**/ ?>