<!DOCTYPE html>
<html>
   <head>
      <!-- Basic -->
      <meta charset="utf-8" />
      <meta http-equiv="X-UA-Compatible" content="IE=edge" />
      <!-- Mobile Metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
      <!-- Site Metas -->
      <meta name="keywords" content="" />
      <meta name="description" content="" />
      <meta name="author" content="" />
      <link rel="shortcut icon" href="home/images/favicon.png" type="">
      <title>Online Auction Project</title>
      <!-- bootstrap core css -->
      <link rel="stylesheet" type="text/css" href="home/css/bootstrap.css" />
      <!-- font awesome style -->
      <link href="home/css/font-awesome.min.css" rel="stylesheet" />
      <!-- Custom styles for this template -->
      <link href="home/css/style.css" rel="stylesheet" />
      <!-- responsive style -->
      <link href="home/css/responsive.css" rel="stylesheet" />

      <style type="text/css">

        .center{
          margin: auto;
          width: 50%;
          border: 2px solid white;
          text-align: center;
          margin-top: 40px;
        }
        .font_size{
          text-align: center;
          font-size: 40px;
          padding-top: 20px;
        }
        .img_size{
          width: 250px;
          height: 150px;
        }
        .th_color{
          background: wheat;
        }
        .th_deg{
          padding: 30px;
        }
        </style>
   </head>
   <body>
      <div class="hero_area">
         <!-- header section strats -->
        <?php echo $__env->make('home.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         <!-- end header section -->


         
         

         <div class="container" style="padding-bottom: 300px">
            <?php if(session()->has('message')): ?>
            <div class="alert alert-success">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">X</button>
        
              <?php echo e(session()->get('message')); ?>

        
            </div>
              
            <?php endif; ?>
            <h1 class="font_size">My Cart</h1>
            <table class="center">
                <thead>
                    <tr class="th_color">
                        <th class="th_deg">Product</th>
                        <th class="th_deg">Image</th>
                        <th class="th_deg">Description</th>
                        <th class="th_deg">Price</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($product->title); ?></td>
                            <td><img src="<?php echo e(asset('product/' . $product->image)); ?>" alt="<?php echo e($product->title); ?>" height="100"></td>
                            <td><?php echo e($product->description); ?></td>
                            <td><?php echo e($product->current_price); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <h2 class="font_size">Total Price: <?php echo e($products->sum('current_price')); ?></h2>
            <form class="center" action="<?php echo e(route('updateDelivery')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button class="btn btn-danger" style="color: black;" type="submit">Deliver To My Address</button>
            </form>
          </div>
          
          



      <!-- footer start -->
      <?php echo $__env->make('home.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- footer end -->
      <div class="cpy_">
         <p class="mx-auto">© 2023 All Rights Reserved By <a href="https://html.design/">Michael Thomas Toyi, Daniel Daro Jimmy, Illoba Paul</a><br>
         
         </p>
      </div>
      <!-- jQery -->
      <script src="home/js/jquery-3.4.1.min.js"></script>
      <!-- popper js -->
      <script src="home/js/popper.min.js"></script>
      <!-- bootstrap js -->
      <script src="home/js/bootstrap.js"></script>
      <!-- custom js -->
      <script src="home/js/custom.js"></script>
   </body>
</html>



<?php /**PATH C:\xampp\htdocs\auction-project-site\resources\views/home/cart.blade.php ENDPATH**/ ?>