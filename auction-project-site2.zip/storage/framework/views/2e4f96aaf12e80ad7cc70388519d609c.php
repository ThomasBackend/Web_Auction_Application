<footer style="background-color:wheat">
  <div class="container">
     <div class="row">
        <div class="col-md-4">
            <div class="full">
               <div class="logo_footer">
                 <a href="#"><img width="210" src="images/logo.png" alt="#" /></a>
               </div>
               <div class="information_f">
                 <p><strong>ADDRESS:</strong> Babcock University, Ilishan-Remo, Ogun State, Nigeria.
                  </p>
                 <p><strong>TELEPHONE:</strong> +234 91 5743 4838</p>
                 <p><strong>EMAIL:</strong> thomasmj.mt@gmail.com</p>
               </div>
            </div>
        </div>
        <div class="col-md-8">
           <div class="row">
           <div class="col-md-7">
              <div class="row">
                 <div class="col-md-6">
              <div class="widget_menu">
                 <h3>Menu</h3>
                 <ul>
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Products</a></li>
                    <li><a href="#">Active Bids</a></li>
                    <li><a href="#">Cart</a></li>
                    <li><a href="#">Won Bids</a></li>
                   
                 </ul>
              </div>
           </div>
           <div class="col-md-6">
              <div class="widget_menu">
                 <h3> Manage Account</h3>
                 <ul>
                    <li><a href="<?php echo e(url('user/profile')); ?>">Profile</a></li>
                    
                 </ul>
              </div>
           </div>
              </div>
           </div>     
           <div class="col-md-5">
              <div class="widget_menu">
                 
                 
              </div>
           </div>
           </div>
        </div>
     </div>
  </div>
</footer><?php /**PATH C:\xampp\htdocs\auction-project-site\resources\views/home/footer.blade.php ENDPATH**/ ?>